function love.conf(t)
 t.window.fullscreen = true
 t.window.fullscreentype = "desktop"
end
  
  